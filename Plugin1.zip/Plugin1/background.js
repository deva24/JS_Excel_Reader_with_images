
chrome.tabs.onUpdated.addListener(function (tabid, changeInfo, tab)
{
    chrome.pageAction.show(tabid);
});

chrome.extension.onMessage.addListener(function (msg, sender)
{
    console.log("Background script has received a message from contentscript:", msg);
    if (msg.action == 'record')
    {
        chrome.storage.sync.get([msg.user], function (obj)
        {
            obj = obj[msg.user];
            if (obj == null)
                obj = {};
            var yesterday = dateStringToDate(msg.yesterdayDate);
            var today = new Date(yesterday);
            today.setDate(today.getDate() + 1);

            var yesterdayStr = dateToDateString(yesterday);
            var todayStr = dateToDateString(today);

            var yObj = obj[yesterdayStr];
            var tObj = obj[todayStr];
            if (yObj == null) yObj = {}
            if (tObj == null) tObj = {}

            if (msg.yesterdayIn)
            {
                yObj.in = msg.yesterdayIn;
                obj[yesterdayStr] = yObj;
            }

            if (msg.yesterdayOut)
            {
                yObj.out = msg.yesterdayOut;
                obj[yesterdayStr] = yObj;
            }

            if (msg.todayIn)
            {
                tObj.in = msg.todayIn;
                obj[todayStr] = tObj;
            }

            if (msg.yesterdayOut)
            {
                tObj.out = msg.todayOut;
                obj[todayStr] = tObj;
            }

            var setObj = {};
            setObj[msg.user] = obj;

            chrome.storage.sync.set(setObj);
        })
    }
    if(msg.action=='import')
    {
        debugger;
        chrome.storage.sync.get(['u' + msg.empId], function (obj)
        {
            var setObj = obj['u' + msg.empId];
            if(setObj==null)setObj={};

            
            msg.days.forEach(dayObj => {
                var dd = dayObj.day;
                var mm = msg.month;
                var yy = msg.year;
                
                if(dd.length==1)dd='0'+dd;
                if(mm.length==1)mm='0'+mm;
                var dateStr = dd+'/'+mm+'/'+yy;
                
                if(dayObj.in && dayObj.out)
                {
                    setObj[dateStr] = {
                        in:{
                            Hours:dayObj.in.h,
                            Minutes:dayObj.in.m,
                        },
                        out:{
                            Hours:dayObj.out.h,
                            Minutes:dayObj.out.m,
                        }
                    };
                    
                }
            });
            obj['u' + msg.empId] = setObj;
            chrome.storage.sync.set(obj);
        });
    }
});

function dateStringToDate(str)
{
    var dates = str.split("/");
    return new Date(dates[2], dates[1]-1, dates[0]);
}

/**@param {Date} d */
function dateToDateString(d)
{
    var dd = d.getDate().toString();
    var mm = (d.getMonth()+1).toString();
    var yy = d.getFullYear().toString();

    if (dd.length == 1) dd = '0' + dd;
    if (mm.length == 1) mm = '0' + mm;
    return dd + "/" + mm + "/" + yy;

}