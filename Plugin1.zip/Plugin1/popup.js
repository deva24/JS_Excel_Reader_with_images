var TimeData = /** @class */ (function ()
{
    function TimeData(h, m)
    {
        if (m === void 0) { m = null; }
        try
        {
            if (m == null)
            {
                if (typeof h === 'string')
                {
                    var hm = h.split(':');
                    h = parseInt(hm[0]);
                    m = parseInt(hm[1]);
                }
                else
                {
                    throw 'Constructor arguments not in format. either provide (hh as string|number,mm as string|number) or ("hh:mm" as string)';
                }
            }
            else if (h == null)
            {
                if (typeof m === 'string')
                    m = Math.abs(parseInt(m));
                h = Math.floor(m / 60);
                m = m % 60;
            }
            else
            {
                if (typeof h === 'string')
                    h = parseInt(h);
                if (typeof m === 'string')
                    m = parseInt(m);
            }
            this.Hours = h;
            this.Minutes = m;
        }
        catch (ex)
        {
            throw 'Constructor arguments not in format. either provide (hh as string|number,mm as string|number) or ("hh:mm" as string)';
        }
    }
    TimeData.prototype.toString = function ()
    {
        var ret = '';
        ret = this.Hours + ':' + this.Minutes;
        return ret;
    };
    return TimeData;
}());

Date.prototype.prevDate = function ()
{
    this.setDate(this.getDate() - 1);
};
Date.prototype.nextDate = function ()
{
    this.setDate(this.getDate() + 1);
};

function dateStringToDate(str)
{
    var dates = str.split("/");
    return new Date(dates[2], dates[1] - 1, dates[0]);
}

/**@param {Date} d */
function dateToDateString(d)
{
    var dd = d.getDate().toString();
    var mm = (d.getMonth() + 1).toString();
    var yy = d.getFullYear().toString();

    if (dd.length == 1) dd = '0' + dd;
    if (mm.length == 1) mm = '0' + mm;
    return dd + "/" + mm + "/" + yy;
}

var UI;
(function (UI)
{
    function Init()
    {
        var div = document.querySelector('div#output');
        div.style.background = 'white';
        var table = document.createElement('table');
        table.style.margin = 'auto';
        table.border = '1';
        table.style.borderCollapse = 'collapse';
        div.appendChild(table);
        UI.getSlot = function getSlot(name)
        {
            var tr = document.createElement('tr');
            table.appendChild(tr);
            var td = document.createElement('td');
            td.innerText = name;
            tr.appendChild(td);
            td = document.createElement('td');
            tr.appendChild(td);
            td.innerText = ":";
            td = document.createElement('td');
            tr.appendChild(td);
            return function (val, color)
            {
                td.innerText = val;
                if (color)
                {
                    td.style.color = color;
                }
            };
        };
        document.querySelector('div#calendar').appendChild(renderCalandar());

    }
    UI.Init = Init;
    UI.getSlot = function (name) { console.warn('UI not initiated'); return function (val) { console.warn('UI not initated'); }; };
    UI.setCalender = function () { console.warn("UI not initiated"); };
    function renderCalandar()
    {
        var today = new Date();
        var thisMonth = today.getMonth();
        var firstDay = new Date(today);
        firstDay.setDate(1);
        var lastDay = new Date(today);
        while (lastDay.getMonth() == thisMonth)
            lastDay.nextDate();
        lastDay.prevDate();
        var weekday = firstDay.getDay();
        while (weekday-- > 0)
            firstDay.prevDate();
        weekday = lastDay.getDay();
        while (6 - (weekday++) > 0)
            lastDay.nextDate();
        var table = document.createElement('table');
        table.border = '1';
        table.style.borderCollapse = 'collapse';
        table.style.tableLayout = 'fixed';
        table.style.width = '100%';
        var tr = document.createElement('tr');
        table.appendChild(tr);
        var weekdays = 'Su,Mo,Tu,We,Th,Fr,Sa'.split(',');
        var td;
        for (var i = 0; i < 7; i++)
        {
            td = document.createElement('td');
            td.innerText = weekdays[i];
            tr.appendChild(td);
        }
        var cnt = 0;
        var datestring;
        var day;
        var month;
        var map_dateToTd = {};
        while (firstDay <= lastDay)
        {
            if (cnt++ % 7 == 0)
            {
                tr = document.createElement('tr');
                table.appendChild(tr);
            }
            day = firstDay.getDate();
            month = firstDay.getMonth();
            datestring = dateToDateString(firstDay);
            td = document.createElement('td');
            td.innerText = day.toString();
            var div1 = document.createElement('div');
            div1.className = 'disp';
            td.appendChild(div1);
            if (month != thisMonth)
                td.style.color = '#AAA';
            tr.appendChild(td);
            map_dateToTd[datestring] = td;
            firstDay.nextDate();
        }
        UI.setCalender = function (datestring, HTMLs)
        {
            var td = map_dateToTd[datestring];
            if (!td)
                return;
            var disp = td.querySelector('.disp');
            if (!disp)
                return;
            disp.innerHTML = HTMLs;
        };
        return table;
    }

    UI.Init();
    slot_inTime = UI.getSlot('In Time');
    slot_outTime = UI.getSlot('Out Time');
    slot_suggestedOutTime = UI.getSlot('Suggested OutTime');
    slot_timeLeft = UI.getSlot('Time Left');
    slot_extraTime = UI.getSlot('Extra Time');
    slot_avgIn = UI.getSlot('Average Punchin');
    slot_avgOut = UI.getSlot('Average Punchout');

    UI.refreshUI = function refreshUI(obj)
    {
        var cnt = 0;
        var t_inMins=0;
        var t_outMins=0;
        var t_everyDaySpan=0;

        var db = obj;
        Object.keys(db).forEach(function (datestring)
        {
            try
            {
                var inTime = db[datestring].in;
                var outTime = db[datestring].out;
                try
                {
                    inTime = new TimeData(inTime.Hours, inTime.Minutes);
                    outTime = new TimeData(outTime.Hours, outTime.Minutes);
                    
                    cnt++;

                    var inMins = inTime.Hours * 60 + inTime.Minutes;
                    var outMins = outTime.Hours * 60 + outTime.Minutes;

                    t_inMins+=inMins;
                    t_outMins+=outMins;      

                    var totalMins = outMins - inMins;
                    t_everyDaySpan+=totalMins;

                    var extraMins = totalMins - 9 * 60;

                    var sign = (extraMins < 0 ? -1 : 1);
                    var tempExtraMin = sign * extraMins;
                    var tempExtrHours = Math.floor(tempExtraMin / 60);
                    tempExtraMin -= tempExtrHours * 60;

                    var extraHrObj = new TimeData(tempExtrHours, tempExtraMin);
                    var txt = inTime.toString() + '<br/>' + outTime.toString() + '<br/>';
                    txt += (sign == -1 ? "<span style='color:red'>-" : "<span style='color:green'>+") + extraHrObj.toString();
                    txt += "</span>";

                    UI.setCalender(datestring, txt, (extraMins > 0));
                }
                catch (ex)
                {
                    //delete db[datestring];
                }
            }
            finally { }
        });

        slot_avgIn( MinsToTimeObj(t_inMins/cnt).toString() );
        slot_avgOut( MinsToTimeObj(t_outMins/cnt).toString() );
        var extraMins = t_everyDaySpan - 9*60*cnt;
        var sign=extraMins/Math.abs(extraMins);
        extraMins *= sign;
        var extraString = "";
        if(sign==-1)extraString = '-';
        extraString += MinsToTimeObj(extraMins).toString();

        slot_extraTime( extraString );
        
        var nowToday = new Date();
        var todayStr = dateToDateString(nowToday);

        if(obj[todayStr])
        {
            var punchIn = obj[todayStr].in;
            var punchInMins = punchIn.Hours*60 + punchIn.Minutes;
            var suggestedPunchOutMins = punchInMins+9*60 - extraMins*sign;
            var suggestedPunchOutTime = MinsToTimeObj(suggestedPunchOutMins);
            slot_suggestedOutTime(suggestedPunchOutTime.toString());
        }
        
    }

})(UI || (UI = {}));


var Model;
(function (Model)
{
    Model.getData = function ()
    {
        return new Promise((res, rej) =>
        {
            chrome.storage.sync.get(null, function (obj)
            {
                res(obj);
            });
        });
    }
    Model.getUser = function ()
    {
        return new Promise((res, rej) =>
        {
            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs)
            {
                chrome.tabs.sendMessage(tabs[0].id, { action: "getuser" });
            });

            chrome.extension.onMessage.addListener(onMessage1)

            function onMessage1(msg, sender)
            {
                if (msg.action != "takeuser")
                {
                    return;
                }

                chrome.extension.onMessage.removeListener(onMessage1);

                res(msg.user);
            }

        });
    }

})(Model || (Model = {}));

Model.getUser().then((user) =>
{
    Model.getData().then(data =>
    {
        if (data[user])
        {
            UI.refreshUI(data[user]);
        }
    });
});


function MinsToTimeObj(mins)
{
    var hrs = Math.floor(mins/60);
    var mins = Math.floor(mins%60);
    return new TimeData(hrs,mins);
}