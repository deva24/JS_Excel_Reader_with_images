var TimeData = /** @class */ (function ()
{
    function TimeData(h, m)
    {
        if (m === void 0) { m = null; }
        try
        {
            if (m == null)
            {
                if (typeof h === 'string')
                {
                    var hm = h.split(':');
                    h = parseInt(hm[0]);
                    m = parseInt(hm[1]);
                }
                else
                {
                    throw 'Constructor arguments not in format. either provide (hh as string|number,mm as string|number) or ("hh:mm" as string)';
                }
            }
            else if (h == null)
            {
                if (typeof m === 'string')
                    m = Math.abs(parseInt(m));
                h = Math.floor(m / 60);
                m = m % 60;
            }
            else
            {
                if (typeof h === 'string')
                    h = parseInt(h);
                if (typeof m === 'string')
                    m = parseInt(m);
            }
            this.Hours = h;
            this.Minutes = m;
        }
        catch (ex)
        {
            throw 'Constructor arguments not in format. either provide (hh as string|number,mm as string|number) or ("hh:mm" as string)';
        }
    }
    TimeData.prototype.toString = function ()
    {
        var ret = '';
        ret = this.Hours + ':' + this.Minutes;
        return ret;
    };
    return TimeData;
}());

var df = /\d{1,2}:\d{1,2}/;
var intF = /Punch\-In updated successfully at/;

function getYesterdayInOutTimeString()
{
    var dom1 = document.getElementById('ContentPlaceHolder1_lblYesterdayInTime');
    var dom2 = document.getElementById('ContentPlaceHolder1_lblYesterdayOutTime');
    if (df.test(dom1.innerText) && df.test(dom2.innerText))
    {
        return {
            in: new TimeData(dom1.innerText.trim()),
            out: new TimeData(dom2.innerText.trim())
        };
    }
    return { in: null, out: null };
}
function updateYesterDayData()
{
    var yesterdayData = getYesterdayInOutTimeString();
    if (yesterdayData.in == null || yesterdayData.out == null)
        return;
    var date = new Date();
    date.setDate(date.getDate() - 1);
    database1.updateData(yesterdayData, date);
}
function getInTime()
{
    var ret = null;
    var dom = document.getElementById('ContentPlaceHolder1_lblPunchInDateTime');
    var dom2 = document.getElementById('ContentPlaceHolder1_lblErroMsg3');
    if (dom != null)
    {
        try
        {
            var str = dom.innerText;
            var res = df.exec(str);
            if (res != null && res.length > 0)
            {
                ret = new TimeData(res[0]);
            }
        }
        catch (ex)
        {
        }
    }
    if (dom2 != null && ret == null)
    {
        try
        {
            var str = dom2.innerText;
            if (intF.test(str))
            {
                var cap = df.exec(str);
                ret = new TimeData(cap[0]);
            }
        }
        finally { }
    }
    return ret;
}
function getOutTime()
{
    var ret = null;
    var dom = document.getElementById('ContentPlaceHolder1_lblErroMsg3');
    if (dom != null)
    {
        try
        {
            var str = dom.innerText;
            if (!intF.test(str))
            {
                var res = df.exec(str);
                if (res.length > 0)
                {
                    ret = new TimeData(res[0]);
                }
            }
        }
        catch (ex)
        {
        }
    }
    return ret;
}
var inTime,outTime;
var prevInTime,prevOutTime;
var lastRecInTime,lastRecOuttime;

function tick()
{
    if (inTime == null)
    {
        inTime = getInTime();
        var k = getYesterdayInOutTimeString();
        prevInTime = k.in;
        prevOutTime = k.out;

        var sendObj = {action:'record'};
        if(inTime)
            sendObj.todayIn = inTime;
        
        if(prevInTime)
            sendObj.yesterdayIn = prevInTime;
        
        if(prevOutTime)
            sendObj.yesterdayOut = prevOutTime;

        var dateDom = document.getElementById('ContentPlaceHolder1_lblYesterdaysDate');
        if(dateDom)
            sendObj.yesterdayDate = dateDom.innerHTML;

        var userDom = document.getElementById('ContentPlaceHolder1_lblEmpCode');
        if(userDom)
            sendObj.user = userDom.innerHTML
        
        chrome.extension.sendMessage(sendObj);
    }
    else
    {
        var dateDom = document.getElementById('ContentPlaceHolder1_lblYesterdaysDate');
        outTime = getOutTime();
        if (outTime != null)
        {

            var doUpdate = false;
            if (outTime != null)
            {
                if (lastRecOuttime == null)
                    doUpdate = true;
                else if (lastRecOuttime.Hours != outTime.Hours || lastRecOuttime.Minutes != outTime.Minutes)
                    doUpdate = true;
            }
            if (doUpdate)
            {
                lastRecInTime = inTime;
                lastRecOuttime = outTime;

                var sendObj = {
                    action:'record',
                    todayOut : outTime
                }

                var dateDom = document.getElementById('ContentPlaceHolder1_lblYesterdaysDate');
                if(dateDom)
                    sendObj.yesterdayDate = dateDom.innerHTML;

                var userDom = document.getElementById('ContentPlaceHolder1_lblEmpCode');
                if(userDom)
                    sendObj.user = userDom.innerHTML

                chrome.extension.sendMessage(sendObj);

            }
        }
    }
}

chrome.extension.onMessage.addListener(function(user,sender)
{
    if(user.action=='getuser')
    {
        var user = "";
        var userDom = document.getElementById('ContentPlaceHolder1_lblEmpCode');
        if(userDom)
            user = userDom.innerHTML;

        chrome.extension.sendMessage({action:"takeuser",user});
    }
});

setInterval(tick,1000);

function dateStringToDate(str)
{
    var dates = str.split("/");
    return new Date(dates[2], dates[1]-1, dates[0]);
}

/**@param {Date} d */
function dateToDateString(d)
{
    var dd = d.getDate().toString();
    var mm = (d.getMonth()+1).toString();
    var yy = d.getFullYear().toString();

    if (dd.length == 1) dd = '0' + dd;
    if (mm.length == 1) mm = '0' + mm;
    return dd + "/" + mm + "/" + yy;

}