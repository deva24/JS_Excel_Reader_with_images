function getId(day, t)
{
    var id = 'DERIVED_SCH_CAL_SCH_TEXT' + t + '_' + day;
    return id;
}
function getDateId(day)
{
    return "DERIVED_SCH_CAL_SCH_DAY_" + day;
}
function readCalendar()
{
    try
    {
        var doc = document.querySelector('iframe').contentDocument;
        var empId = doc.querySelector('#SCH_EE_PER_SRCH_EMPLID').innerText;
        var month = doc.querySelector('#DERIVED_SCH_CAL_MONTH_XLAT').value;
        var year = doc.querySelector('#DERIVED_SCH_CAL_YEAR_XLAT').value;
        var arr = [];
        for (var i = 1; i <= 45; i++)
        {
            var id = getId(i, 2);
            var elem = doc.getElementById(id);
            if (elem == null)
                continue;
            var dateElem = doc.getElementById(getDateId(i));
            if (dateElem == null)
                continue;
            var dateString = '';
            dateString = dateElem.innerText.trim();
            if (dateString == '')
                continue;
            var cap = /(\d{1,2})\.(\d{1,2})\-(\d{1,2})\.(\d{1,2})/g;
            var txt = elem.innerText;
            if (txt == null || txt.trim() == '')
                continue;
            var res = cap.exec(txt);
            if (res.length == 0)
                continue;
            var punchInTime = { h: parseInt(res[1]), m: parseInt(res[2]) };
            var punchOutTime = { h: parseInt(res[3]), m: parseInt(res[4]) };
            arr.push({
                day: dateString,
                in: punchInTime,
                out: punchOutTime
            });
        }
        return { days: arr, month, year,empId };
    }
    catch (ex)
    {

    }
}
(function(){
    var c = setInterval(function ()
    {
        var arr = readCalendar();
        if(arr)
        {
            clearInterval(c);            
            arr.action='import';
            debugger;
            chrome.extension.sendMessage(arr);
        }
    }, 1000);
})();